

//
//  ZCViewController1.m
//  蓝牙demo
//
//  Created by zhangcheng on 14-7-30.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import "ZCViewController1.h"
#import "ZCBluetoothManager.h"
@interface ZCViewController1 ()
{
}
@property(nonatomic,strong)NSMutableArray*dataArray;
@end

@implementation ZCViewController1

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIButton*button1=[UIButton buttonWithType:UIButtonTypeCustom];
    button1.frame=CGRectMake(120, 100, 100, 100);
    [button1 setTitle:@"发送消息" forState:UIControlStateNormal];
    button1.backgroundColor=[UIColor greenColor];
    [button1 addTarget:self action:@selector(sendMessage) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button1];
    UIButton*button2=[UIButton buttonWithType:UIButtonTypeCustom];
    button2.frame=CGRectMake(120, 200, 100, 100);
    [button2 setTitle:@"发送消息toArduino" forState:UIControlStateNormal];
    button2.backgroundColor=[UIColor redColor];
    [button2 addTarget:self action:@selector(sendMessageToArduino) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button2];
    [[ZCBluetoothManager shareManager]loadMessgae:^(NSString *xx) {
        NSLog(@"%@",xx);
    }];

    
    
}
-(void)sendMessageToArduino{
    [[ZCBluetoothManager shareManager]sendMessageToArduino:@"<#11G1CS128>" Block:^(int a) {
        if (a) {
            NSLog(@"发送成功");

        }
    }];
    
}
-(void)sendMessage{
    
    
      [[ZCBluetoothManager shareManager] sendMessageToiPhone:@"哈哈哈" Block:^(int a) {
        if (a) {
            NSLog(@"发送成功");
        }
    }];
   
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
