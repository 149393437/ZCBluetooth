//  ZCBluetoothManager.h
//  蓝牙demo
//
//  Created by 张诚 on 15/5/20.
//  Copyright (c) 2015年 zhangcheng. All rights reserved.

//                          _oo8oo_
//                         o8888888o
//                         88" . "88
//                         (| -_- |)
//                         0\  =  /0
//                       ___/'==='\___
//                     .' \\|     |// '.
//                    / \\|||  :  |||// \
//                   / _||||| -:- |||||_ \
//                  |   | \\\  -  /// |   |
//                  | \_|  ''\---/''  |_/ |
//                  \  .-\__  '-'  __/-.  /
//                ___'. .'  /--.--\  '. .'___
//             ."" '<  '.___\_<|>_/___.'  >' "".
//            | | :  `- \`.:`\ _ /`:.`/ -`  : | |
//            \  \ `-.   \_ __\ /__ _/   .-` /  /
//        =====`-.____`.___ \_____/ ___.`____.-`=====
//                          `=---=`
//
//                  佛祖保佑            永无bug
//     _                            _
// ___| |__   __ _ _ __   __ _  ___| |__   ___ _ __   __ _
//|_  / '_ \ / _` | '_ \ / _` |/ __| '_ \ / _ \ '_ \ / _` |
// / /| | | | (_| | | | | (_| | (__| | | |  __/ | | | (_| |
///___|_| |_|\__,_|_| |_|\__, |\___|_| |_|\___|_| |_|\__, |
//                       |___/                       |___/

//小张诚技术博客http://blog.sina.com.cn/u/2914098025
//github代码地址https://github.com/149393437
//欢迎加入iOS研究院 QQ群号305044955    你的关注就是我开源的动力
/*
 说明
 蓝牙需要实现双向通信的原理
 A与B都发出广播
 但是只能B扫描出A，链接A，向A发送订阅消息，可以接收到A发出的信息
 但是B发出的A无法接收到，因为A没有订阅B的消息
 此时A发起扫描 就可以发现B了，然后订阅消息，则可以实现双向通信了
 
 也就是说，广播和扫描需要同时启动
 就可以实现双向通信
 
 BUG说明
 硬件条件 ipad4版本为8.1 iphone6为8.3版本 iphone6+版本为8.1.2版本
 测试1   8.1发出的广播，8.1.2收不到
 测试2   8.1.2发出的广播，8.1可以收到
 升级iphone6+ 版本8.3
 测试1   8.1版本的蓝牙发出的广播，8.3版本的是收不到的
 测试2   8.3版本发出的，8.1版本是可以收到的
 测试3   8.3版本发出的 8.3是可以收到的
 升级ipad   版本8.3 可以实现双向通信
 
 结论  8.1版本蓝牙的发出的广播是有bug的，导致与8.1版本设备链接变为单向的链接，这个bug在8.1.2修复了
 
 
 */
//服务
#define SERVICE_UUID     0xFFE0
//特性
#define CHAR_UUID        0xFFE1

//传输文件，传输完毕的语意
#define BluetoothEnd @"END"

//每一段不能超过20字节
#define NOTIFY_MTU 20

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
@interface ZCBluetoothManager : NSObject<CBPeripheralManagerDelegate,CBCentralManagerDelegate,CBPeripheralDelegate>
#pragma mark 中心设备负责连接服务，对于连接的是单片机，还要承担发送服务
//中心管理类
@property(nonatomic,strong)CBCentralManager*centralManager;
//接收数据
@property(nonatomic,strong)NSMutableData*data;
//链接的设备
@property(nonatomic,strong)CBPeripheral*discovedPeripheral;
//写入数据的特性
@property(nonatomic,strong)CBCharacteristic*writeCharacteristic;
//block指针
@property(nonatomic,copy)void(^blockValue)(NSString*);
+(instancetype)shareManager;
-(void)loadMessgae:(void(^)(NSString*))a;


#pragma mark 周边设备负责广播数据，让别人接收，一旦有人订阅，则可以触发链接
//周边设备管理类
@property(nonatomic,strong)CBPeripheralManager*peripheralManager;
//可变服务特性
@property(nonatomic,strong)CBMutableCharacteristic*transferCharacteristic;
//发送的消息
@property(nonatomic,copy)NSString*message;
//从第几字节开始发送
@property(nonatomic)NSInteger sendDataIndex;
//发送的数据
@property(nonatomic,strong)NSData*sendData;
//发送数据成功的回调
@property(nonatomic,copy)void(^BlockResult)(int);
-(void)sendDataClick;
-(void)sendMessageToiPhone:(NSString*)str Block:(void(^)(int))a;

@end


