//
//  ZCBluetoothManager.m
//  蓝牙demo
//
//  Created by 张诚 on 15/5/20.
//  Copyright (c) 2015年 zhangcheng. All rights reserved.
//
//个人技术博客http://blog.sina.com.cn/u/2914098025
//github代码地址https://github.com/149393437
//欢迎加入iOS研究院 QQ群号305044955    你的关注就是我开源的动力
#import "ZCBluetoothManager.h"
static ZCBluetoothManager*manager=nil;
static BOOL sendingEOM = NO;
@implementation ZCBluetoothManager

#pragma mark ********中心设备方法****************
-(CBUUID*)createUUID:(int)uuid{
    UInt16 temp = uuid << 8;
    temp |= (uuid >> 8);
    NSData *sd = [[NSData alloc] initWithBytes:(char *)&temp length:2];
    CBUUID *su = [CBUUID UUIDWithData:sd];
    return su ;
}
+(instancetype)shareManager{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager=[[ZCBluetoothManager alloc]init];
    });
    return manager;
}
-(void)loadMessgae:(void (^)(NSString *))a
{
    self.blockValue=a;
}

-(id)init{
    if (self=[super init]) {
        self.centralManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil];
        self.data=[NSMutableData data];
         self.peripheralManager=[[CBPeripheralManager alloc]initWithDelegate:self queue:nil];
    }
    return self;
}


//检测中央设备状态
-(void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    
    if (central.state!=CBCentralManagerStatePoweredOn) {
        //如果蓝牙关闭，那么无法开启检测，直接返回
        NSLog(@"蓝牙关闭");
        return;
    }
    //开启检测
    [self scan];
    
}

-(void)scan{
    [self.centralManager scanForPeripheralsWithServices:@[[self createUUID:SERVICE_UUID]] options:@{CBCentralManagerScanOptionAllowDuplicatesKey : @YES }];
    //options中的意思是否允许中央设备多次收到曾经监听到的设备的消息，这样来监听外围设备联接的信号强度，以决定是否增大广播强度，为YES时会多耗电
    
}
//当外围设备广播同样的UUID信号被发现时，这个代理函数被调用。这时我们要监测RSSI即Received Signal Strength Indication接收的信号强度指示，确保足够近，我们才连接它
- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI
{
    
    
    NSLog(@"Discovered %@ at %@", peripheral.name, RSSI);
    
    // 判断是不是我们监听到的外围设备
    if (self.discovedPeripheral != peripheral) {
        self.discovedPeripheral = peripheral;
        [self.centralManager connectPeripheral:peripheral options:nil];;
        
        NSLog(@"Connecting to peripheral %@", peripheral);
        [self performSelector:@selector(xx) withObject:nil afterDelay:0.1];
    }
}
-(void)xx{
    [self.centralManager stopScan];
}
//连接上外围设备后我们就要找到外围设备的服务特性
-(void)centralManager:(CBCentralManager *)central didConnectPeripheral:(CBPeripheral *)peripheral
{
    
    //连接完成后，就停止检测
    [self.centralManager stopScan];
    
    [self.data setLength:0];
    //确保我们收到的外围设备连接后的回调代理函数
    peripheral.delegate=self;
    //让外围设备找到与我们发送的UUID所匹配的服务
    [peripheral discoverServices:@[[self createUUID:SERVICE_UUID]]];
    
}

//相当于对方的账号
-(void)peripheral:(CBPeripheral *)peripheral didDiscoverServices:(NSError *)error{
    
    if (error) {
        NSLog(@"Errordiscover:%@",error.localizedDescription);
        [self clearUp];
        return;
    }
    //找到我们想要的特性
    //遍历外围设备
    for (CBService*server in peripheral.services) {
        [peripheral discoverCharacteristics:@[[self createUUID:CHAR_UUID]] forService:server];
    }
    
}
//当发现传送服务特性后我们要订阅他 来告诉外围设备我们想要这个特性所持有的数据
-(void)peripheral:(CBPeripheral *)peripheral didDiscoverCharacteristicsForService:(CBService *)service error:(NSError *)error
{
    if (error) {
        NSLog(@"error  %@",[error localizedDescription]);
        [self clearUp];
        return;
    }
    //检查特性
    for (CBCharacteristic*characteristic in service.characteristics) {
        if ([characteristic.UUID isEqual:[self createUUID:CHAR_UUID]]) {
            //有来自外围的特性，找到了，就订阅他
            // 如果第一个参数是yes的话，就是允许代理方法peripheral:didUpdateValueForCharacteristic:error: 来监听 第二个参数 特性是否发生变化
            [peripheral setNotifyValue:YES forCharacteristic:characteristic];
            //完成后，等待数据传进来
            NSLog(@"订阅成功");
            //使用discovedPeripheral和characteristic就可以给另外一个进行发送数据了
            self.discovedPeripheral=peripheral;
            //记住特性
            self.writeCharacteristic=characteristic;
            
            [NSTimer scheduledTimerWithTimeInterval:5 target:self selector:@selector(sendMessage) userInfo:nil repeats:YES];
        }
    }
    
}
-(void)sendMessage{
    [self.discovedPeripheral writeValue:[@"<#11G1CS128>" dataUsingEncoding:NSUTF8StringEncoding] forCharacteristic:self.writeCharacteristic type:CBCharacteristicWriteWithoutResponse];
    
}

//这个函数类似网络请求时候只需收到数据的那个函数
-(void)peripheral:(CBPeripheral *)peripheral didUpdateValueForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    if (error) {
        NSLog(@"error~~%@",error.localizedDescription);
        return;
    }
    //characteristic.value 是特性中所包含的数据
    NSString*stringFromData=[[NSString alloc]initWithData:characteristic.value encoding:NSUTF8StringEncoding];
    NSLog(@"%@",stringFromData);
    
    if ([stringFromData isEqualToString:BluetoothEnd]) {
        //完成发送，调用代理进行传递self.data
        NSString*str=[[NSString alloc]initWithData:self.data encoding:NSUTF8StringEncoding];
        //取消订阅
        //        [peripheral setNotifyValue:NO forCharacteristic:characteristic];
        //        [self.centralManager cancelPeripheralConnection:peripheral];
        self.blockValue(str);
        [self.data setLength:0];
        
    }else{
        //数据没有传递完成，继续传递数据
        [self.data appendData:characteristic.value];
        
    }
    
}
//外围设备让我们知道，我们订阅和取消订阅是否发生
-(void)peripheral:(CBPeripheral *)peripheral didUpdateNotificationStateForCharacteristic:(CBCharacteristic *)characteristic error:(NSError *)error
{
    if (error) {
        NSLog(@"error  %@",error.localizedDescription);
    }
    //如果不是我们要特性就退出
    if (![characteristic.UUID isEqual:[self createUUID:CHAR_UUID]]) {
        return;
    }
    
    if (characteristic.isNotifying) {
        NSLog(@"外围特性通知开始");
    }else{
        NSLog(@"外围设备特性通知结束，也就是用户要下线或者离开%@",characteristic);
        //断开连接
        [self.centralManager cancelPeripheralConnection:peripheral];
        
    }
}
-(void)centralManager:(CBCentralManager *)central didDisconnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    NSLog(@"disconnected");
    self.discovedPeripheral=nil;
    [self scan];
}
//连接失败时的处理
-(void)centralManager:(CBCentralManager *)central didFailToConnectPeripheral:(CBPeripheral *)peripheral error:(NSError *)error
{
    NSLog(@"Failed to connect to %@~~~%@",peripheral,[error localizedDescription]);
    [self clearUp];
    
}

-(void)clearUp{
    if (self.discovedPeripheral.state!=CBPeripheralStateConnected) {
        return;
    }
    if (self.discovedPeripheral.services!=nil) {
        for (CBService*server in self.discovedPeripheral.services) {
            
            if (server.characteristics!=nil) {
                for (CBCharacteristic*chatacter in server.characteristics) {
                    
                    if ([chatacter.UUID isEqual:[self createUUID:CHAR_UUID]]) {
                        
                        //查看是否订阅了
                        if (chatacter.isNotifying) {
                            //如果订阅了。取消订阅
                            [self.discovedPeripheral setNotifyValue:NO forCharacteristic:chatacter];
                            return;
                        }
                        
                    }
                    
                }
            }
        }
    }
    //如果我们连接了，但是没有订阅，就断开连接即可
    [self.centralManager cancelPeripheralConnection:self.discovedPeripheral];
    
}
#pragma mark ************周边设备*********************
-(void)sendMessageToiPhone:(NSString*)str Block:(void(^)(int))a{
    self.BlockResult=a;
    self.message=str;
    self.sendDataIndex=0;
    [self sendDataClick];
    
}
//检测状态
-(void)peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral
{
    if (peripheral.state!=CBPeripheralManagerStatePoweredOn) {
        return;
    }
    //启动service
    //启动可变服务特性properties：Notify允许没有回答的服务特性，向中心设备发送数据，permissions：read通讯属性为只读
    self.transferCharacteristic=[[CBMutableCharacteristic alloc]initWithType:[self createUUID:CHAR_UUID] properties:CBCharacteristicPropertyNotify value:nil permissions:CBAttributePermissionsReadable];
    //创建服务 primary 是首次还是第二次
    CBMutableService*transferService=[[CBMutableService alloc]initWithType:[self createUUID:SERVICE_UUID] primary:YES];
    //把特性加到服务上
    transferService.characteristics=@[self.transferCharacteristic];
    //把服务加到管理上
    [self.peripheralManager addService:transferService];
    
    //发送广播，标示是TRANSFER_SERVICE_UUID为对方观察接收的值，2边要对应上
    
    [self.peripheralManager startAdvertising:@{CBAdvertisementDataServiceUUIDsKey:@[[self createUUID:SERVICE_UUID]]}];
}

//当发现我们的人订阅了我们的特性后，我们要发送数据给他
-(void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didSubscribeToCharacteristic:(CBCharacteristic *)characteristic
{
    NSLog(@"订阅成功~~~%@",characteristic.value);
}
//当中央设备结束订阅时候调用
-(void)peripheralManager:(CBPeripheralManager *)peripheral central:(CBCentral *)central didUnsubscribeFromCharacteristic:(CBCharacteristic *)characteristic
{
    NSLog(@"订阅结束");
}

-(void)sendDataClick{
    
    if (sendingEOM) {
        //第三个参数代表指定与我们的订阅的中心设备发送，返回一个布尔值，代表发送成功
        BOOL didSend=[self.peripheralManager updateValue:[BluetoothEnd dataUsingEncoding:NSUTF8StringEncoding] forCharacteristic:self.transferCharacteristic onSubscribedCentrals:nil];
        
        if (didSend) {
            //全部发送完成
            sendingEOM=NO;
            NSLog(@"发送完成");
            self.BlockResult(1);
        }
        //如果没有发送，我们就要退出并且等待
        //peripheralManagerIsReadyToUpdateSubscribers 来再一次调用sendData来发送数据
        return;
    }
    //如果没有正在发送BluetoothEnd，就是在发送数据
    self.sendData=[self.message dataUsingEncoding:NSUTF8StringEncoding];
    //判断是否还有剩下的数据
    if (self.sendDataIndex>=self.sendData.length) {
        //没有数据，退出即可
        return;
    }
    //如果有数据没有发送完就发送它，除非回调失败或者我们发送完
    BOOL didSend=YES;
    while (didSend) {
        //发送下一块数据，计算出数据有多大
        NSInteger amountToSend=self.sendData.length-self.sendDataIndex;
        if (amountToSend>NOTIFY_MTU) {
            //如果剩余的数据还是大于20字节，那么我最多传送20字节
            amountToSend=NOTIFY_MTU;
        }
        //切出我想要发送的数据 +sendDataIndex就是从多少字节开始向后切多少
        NSData*chunk=[NSData dataWithBytes:self.sendData.bytes+self.sendDataIndex length:amountToSend];
        //发送
        didSend=[self.peripheralManager updateValue:chunk forCharacteristic:self.transferCharacteristic onSubscribedCentrals:nil];
        //如果没发送成功，等待回调发送
        if (!didSend) {
            return;
        }else{
            self.sendDataIndex+=amountToSend;
            //判断是否发送完
            if (self.sendDataIndex>=self.sendData.length) {
                //发送完成，就开始发送结束标示bluetoothEND
                sendingEOM=YES;
                [self performSelector:@selector(sendDataClick) withObject:nil afterDelay:0.1];
         
                
            }
        }
        
    }
}
////当以上发送队列满了，导致发送失败时候，会再次准备发送
//-(void)peripheralManagerIsReadyToUpdateSubscribers:(CBPeripheralManager *)peripheral
//{
//    [self sendDataClick];
//}

@end
