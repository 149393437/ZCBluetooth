//
//  ZCAppDelegate.h
//  蓝牙demo
//
//  Created by zhangcheng on 14-7-29.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
