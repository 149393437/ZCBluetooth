//
//  main.m
//  蓝牙demo
//
//  Created by zhangcheng on 14-7-29.
//  Copyright (c) 2014年 zhangcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ZCAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ZCAppDelegate class]));
    }
}
