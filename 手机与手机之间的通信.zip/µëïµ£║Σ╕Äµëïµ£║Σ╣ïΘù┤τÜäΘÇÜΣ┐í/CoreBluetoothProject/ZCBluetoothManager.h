//  ZCBluetoothManager.h
//  蓝牙demo
//
//  Created by 张诚 on 15/5/20.
//  Copyright (c) 2015年 zhangcheng. All rights reserved.

//                          _oo8oo_
//                         o8888888o
//                         88" . "88
//                         (| -_- |)
//                         0\  =  /0
//                       ___/'==='\___
//                     .' \\|     |// '.
//                    / \\|||  :  |||// \
//                   / _||||| -:- |||||_ \
//                  |   | \\\  -  /// |   |
//                  | \_|  ''\---/''  |_/ |
//                  \  .-\__  '-'  __/-.  /
//                ___'. .'  /--.--\  '. .'___
//             ."" '<  '.___\_<|>_/___.'  >' "".
//            | | :  `- \`.:`\ _ /`:.`/ -`  : | |
//            \  \ `-.   \_ __\ /__ _/   .-` /  /
//        =====`-.____`.___ \_____/ ___.`____.-`=====
//                          `=---=`
//
//                  佛祖保佑            永无bug
//     _                            _
// ___| |__   __ _ _ __   __ _  ___| |__   ___ _ __   __ _
//|_  / '_ \ / _` | '_ \ / _` |/ __| '_ \ / _ \ '_ \ / _` |
// / /| | | | (_| | | | | (_| | (__| | | |  __/ | | | (_| |
///___|_| |_|\__,_|_| |_|\__, |\___|_| |_|\___|_| |_|\__, |
//                       |___/                       |___/

//小张诚技术博客http://blog.sina.com.cn/u/2914098025
//github代码地址https://github.com/149393437
//欢迎加入iOS研究院 QQ群号305044955    你的关注就是我开源的动力
/*
2.0版本
 修复在iOS8无法扫描的bug,并且修复给单片发送,数据切割字符串的问题
 
 
 */
//服务
#define SERVICE_UUID     0xFFE0
//特性
#define CHAR_UUID        0xFFE1

//传输文件，传输完毕的语意
#define BluetoothEnd @"END"

//连接成功
#define ConnectSucceed @"连接成功"
//链接失败
#define ConnectError @"连接失败"


//每一段不能超过20字节
#define NOTIFY_MTU 20

#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>
@interface ZCBluetoothManager : NSObject<CBPeripheralManagerDelegate,CBCentralManagerDelegate,CBPeripheralDelegate>
//单例
+(instancetype)shareManager;
//给iphone发送
-(void)sendMessageToiPhone:(NSString*)str Block:(void(^)(int))a;
//给单片机发送
-(void)sendMessageToArduino:(NSString*)str Block:(void(^)(int))a;
//关闭扫描
-(void)stopConnect;
//具备开始扫描和读取功能
-(void)loadMessgae:(void(^)(NSString*))a;



/**************************************************/
#pragma mark 中心设备负责连接服务，对于连接的是单片机，还要承担发送服务
//中心管理类
@property(nonatomic,strong)CBCentralManager*centralManager;
//接收数据
@property(nonatomic,strong)NSMutableData*data;
//链接的设备
@property(nonatomic,strong)CBPeripheral*discovedPeripheral;
//写入数据的特性
@property(nonatomic,strong)CBCharacteristic*writeCharacteristic;
//block指针
@property(nonatomic,copy)void(^blockValue)(NSString*);
#pragma mark 周边设备负责广播数据，让别人接收，一旦有人订阅，则可以触发链接
//周边设备管理类
@property(nonatomic,strong)CBPeripheralManager*peripheralManager;
//可变服务特性
@property(nonatomic,strong)CBMutableCharacteristic*transferCharacteristic;
//发送的消息
@property(nonatomic,copy)NSString*message;
//从第几字节开始发送
@property(nonatomic)NSInteger sendDataIndex;
//发送的数据
@property(nonatomic,strong)NSData*sendData;
//发送数据成功的回调
@property(nonatomic,copy)void(^BlockResult)(int);
@property(nonatomic,copy)void(^blockConnect)(BOOL);
@property(nonatomic)BOOL isDevice;



@end


