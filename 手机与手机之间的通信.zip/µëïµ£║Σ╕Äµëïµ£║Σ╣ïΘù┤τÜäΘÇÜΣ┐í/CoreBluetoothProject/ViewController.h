//
//  ViewController.h
//  CoreBluetoothProject
//
//  Created by zhangcheng on 16/5/18.
//  Copyright © 2016年 zhangcheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *desLabel;


@end

