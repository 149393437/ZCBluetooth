//
//  ViewController.m
//  CoreBluetoothProject
//
//  Created by zhangcheng on 16/5/18.
//  Copyright © 2016年 zhangcheng. All rights reserved.
//

#import "ViewController.h"
#import "ZCBluetoothManager.h"
@interface ViewController ()
{
    ZCBluetoothManager*manager;
    
    BOOL isStar;
    
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createBlueTooth];

    // Do any additional setup after loading the view, typically from a nib.
}
-(void)createBlueTooth{
    manager=[ZCBluetoothManager shareManager];
    [manager loadMessgae:^(NSString * message) {
        if ([message isEqualToString:@"1"]) {
            _desLabel.text=@"开灯";
        }else{
            _desLabel.text=@"关灯";
        }
    }];


}
- (IBAction)connectClick:(id)sender {
    //初始化蓝牙
    [self createBlueTooth];

    
}

//发送消息
- (IBAction)starClick:(id)sender {
    isStar=!isStar;
    NSString*xx=[NSString stringWithFormat:@"%d",isStar];

    [manager sendMessageToiPhone:xx Block:^(int a) {
    
    }];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
